
import Foundation

print("Hello, World!")

var shivam = PermanentEmployee(empID: 101, empName: "Shivam", basicPay: 1245.3, holiday: 2)
shivam.display()

var dhyanee = PermanentEmployee(empID: 102, empName: "Dhyanee", basicPay: 4231.67, holiday: 4)
dhyanee.display()

var gurjot = PermanentEmployee(empID: 103, empName: "Gurjot", basicPay: 2342.2, holiday: 12)
gurjot.display()

let dateCurrent = Date()
print("Date 1 : \(dateCurrent)")

let dateString = "12/01/2003"
let dateFormatter = DateFormatter()
dateFormatter.dateFormat = "MM/dd/yyyy"
let dateFromString = dateFormatter.date(from: dateString)
print("Date 2 : \(dateFromString!)")

print(" 1 is prime ? \(1.isPrime)")
print(" 2 is prime ? \(2.isPrime)")
print(" 3 is prime ? \(3.isPrime)")
print(" 10 is prime ? \(10.isPrime)")

print("length of string \("Hello".length)")

5.wish {
    print("Happy Birthday !")
}

print("digit at index 1 in number 12345 is \(12345[1])")









