//
//  Passenger.swift
//  AirlineReservationSystem
//
//  Created by Jiya Patreja on 2018-07-22.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import Foundation

class Passenger : IDisplay {
    
    var passengerID: Int?
    var passengerPassportNumber: String?
    var passengerName: String?
    var passengerMobile: String?
    var passengerEmail: String?
    var passengerAddress: String?
    var passengerBirthDate: String? //date
    
    
    var PassengerID: Int?{
        get{return self.passengerID!}
        set{self.passengerID = newValue}
    }
    
    var PassengerPassportNumber : String?{
        get{return self.passengerPassportNumber}
        set{self.passengerPassportNumber = newValue}
    }
    var PassengerName: String?{
        get{return self.passengerName}
        set{self.passengerName = newValue}
    }
    var PassengerMobile: String?{
        get{return self.passengerMobile}
        set{self.passengerMobile = newValue}
    }
    var PassengerEmail: String?{
        get{return self.passengerEmail}
        set{self.passengerEmail = newValue}
    }
    var PassengerAddress: String?{
        get{return self.passengerAddress}
        set{self.passengerAddress = newValue}
    }
    var PassengerBirthDate : String?{
        get{return self.passengerBirthDate}
        set{self.passengerBirthDate = newValue}
    }
    
    init(){
        self.passengerID = 0
        self.passengerPassportNumber = ""
        self.passengerName = ""
        self.passengerMobile = ""
        self.passengerEmail = ""
        self.passengerAddress = ""
        self.passengerBirthDate = ""
        
        
    }
    init(passengerID: Int, passengerPassportNumber: String , passengerName: String,  passengerMobile: String, passengerEmail: String, passengerAddress: String, passengerBirthDate: inout String) {
        
        self.passengerID = passengerID
        self.passengerPassportNumber = passengerName
        self.passengerName = passengerName
        self.passengerMobile = passengerMobile
        self.passengerEmail = passengerEmail
        self.passengerAddress = passengerAddress
        
    }
    func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Passenger ID: \(self.passengerID)"
        returnData += "\n Passenger Passport Number: \(self.passengerPassportNumber ?? "")"
        returnData += "\n Passenger Name: \(self.passengerName ?? "")"
        returnData += "\n Passenger Mobile: \(self.passengerMobile ?? "")"
        returnData += "\n Passenger Email: \(self.passengerEmail ?? "")"
        returnData += "\n Passenger Address : \(self.passengerAddress ?? "")"
        returnData += "\n Passenger Date Of Birth: \(self.passengerBirthDate ?? "")"
        
        
        return returnData
    }
    
    func newPassenger(){
        print("Enter Passenger ID : ")
        self.passengerID = (Int)(readLine()!)!
        print("Enter Passenger Passport Number : ")
        self.passengerPassportNumber = readLine()
        print("Enter Passenger Name : ")
        self.passengerName = readLine()
        print("Enter Passenger Mobile : ")
        self.passengerMobile = readLine()
        print("Enter Passenger Email : ")
        self.passengerEmail = readLine()
        print("Enter Passenger Address : ")
        self.passengerAddress = readLine()
        print("Enter Passenger Date Of Birth : ")
        self.passengerBirthDate = readLine()
        print(passengerBirthDate)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // This formate is input formated .
        
        let formateDate = dateFormatter.date(from:passengerBirthDate!)!
        dateFormatter.dateFormat = "MM-dd-yyyy" // Output Formated
        
        print ("Print :\(dateFormatter.string(from: formateDate))")//Print :02-02-2018
        passengerBirthDate = dateFormatter.string(from: formateDate)
     
        
    }
    
    
}


