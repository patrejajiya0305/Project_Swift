//
//  Airlines.swift
//  AirlineReservationSystem
//
//  Created by Jiya Patreja on 2018-07-22.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import Foundation

class Airlines : Plane{
    var airlinesID: Int?
    var airlinesDescription : String?
    var airlinesType : String?
    
    
    var AirlinesID: Int?{
        get{return self.airlinesID!}
        set{self.airlinesID = newValue}
    }
    
    var AirlinesDescription : String?{
        get{return self.airlinesType}
        set{self.airlinesDescription = newValue}
    }
    
    var AirlinesType: String?{
        get{return self.airlinesType}
        set{self.airlinesType = newValue}
    }
    
    
    override init(){
        self.airlinesID = 0
        self.airlinesDescription = ""
        self.airlinesType = ""
        super.init()
        
        
    }
    
    init(airlinesID: Int , airlinesDescription: String, airlinesType: String){
        self.airlinesID = airlinesID
        self.airlinesDescription = airlinesDescription
        self.airlinesType = airlinesType
        super.init()
        
        
        
    }
    
    override func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Airlines Id: \(self.airlinesID)"
        returnData += "\n Airlines Description: \(self.airlinesDescription ?? "")"
        returnData += "\n Airlines Type : \(self.airlinesType ?? "")"
        
        
        return returnData
    }
    
    func newAirlines(){
        print("Enter Airlines ID : ")
        self.AirlinesID = (Int)(readLine()!)!
        print("Enter Airlines Description : ")
        self.airlinesDescription = readLine()!
        print("Enter Airlines Type : ")
        self.airlinesType = readLine()!
        
        
        
        
        
        
        
    }
}


