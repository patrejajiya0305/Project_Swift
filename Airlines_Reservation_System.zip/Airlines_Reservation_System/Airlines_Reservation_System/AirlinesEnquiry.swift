//
//  AirlinesEnquiry.swift
//  AirlineReservationSystem
//
//  Created by Jiya Patreja on 2018-07-22.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import Foundation

class AirlinesEnquiry : IDisplay {
    var enquiryID: Int?
    var enquiryType: String?
    var enquiryTitle: String?
    var enquiryDescription : String?
    var enquiryDate : String? //date
    
    
    var EnquiryID: Int?{
        get{return self.enquiryID!}
        set{self.enquiryID = newValue}
    }
    
    var EnquiryType : String?{
        get{return self.enquiryType}
        set{self.enquiryType = newValue}
    }
    
    var EnquiryTitle: String?{
        get{return self.enquiryTitle}
        set{self.enquiryTitle = newValue}
    }
    var EnquiryDescription: String?{
        get{return self.enquiryDescription}
        set{self.enquiryDescription = newValue}
    }
    var EnquiryDate: String?{
        get{return self.enquiryDate}
        set{self.enquiryDate = newValue}
    }
    
    
    init(){
        self.enquiryID = 0
        self.enquiryType = ""
        self.enquiryTitle = ""
        self.enquiryDescription = ""
        self.enquiryDate = ""
        
    }
    
    init(enquiryID: Int, enquiryType : String, enquiryTitle: String, enquiryDescription : String , enquiryDate : String){
        self.enquiryID = enquiryID
        self.enquiryType = enquiryType
        self.enquiryTitle = enquiryTitle
        self.enquiryDescription = enquiryDescription
        self.enquiryDate = enquiryDate
        
    }
    
    func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Enquiry Id: \(self.enquiryID)"
        returnData += "\n Enquiry Type: \(self.enquiryType ?? "")"
        returnData += "\n Enquiry Title: \(self.enquiryTitle ?? "")"
        returnData += "\n Enquiry Description : \(self.enquiryDescription ?? "")"
        returnData += "\n Enquiry Date: \(self.enquiryDate ?? "")"
        
        
        return returnData
    }
    
    func newEnquiry(){
        print("Enter Enquiry ID : ")
        self.enquiryID = r(Int)(readLine()!)!
        print("Enter Enquiry Type : ")
        self.enquiryType = readLine()!
        print("Enter Enquiry Title : ")
        self.enquiryTitle = readLine()!
        print("Enter Enquiry Description : ")
        self.enquiryDescription = readLine()!
        print("Enter Enquiry Date : ")
        self.enquiryDate = readLine()!
        
    }
}

