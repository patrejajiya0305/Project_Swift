//
//  Employee.swift
//  AirlineReservationSystem
//
//  Created by Jiya Patreja on 2018-07-21.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import Foundation

class Employee : IDisplay {
    
    var employeeID: Int?
    var employeeName: String?
    var employeeEmail: String?
    var employeeMobile: String?
    var employeeAddress: String?
    var employeeDesignation: String?
    var employeeSinNumber: String?
    
    var EmployeeID: Int?{
        get{return self.employeeID!}
        set{self.employeeID = newValue}
    }
    
    var EmployeeName : String?{
        get{return self.employeeName}
        set{self.employeeName = newValue}
    }
    
    var EmployeeEmail: String?{
        get{return self.employeeEmail}
        set{self.employeeEmail = newValue}
    }
    
    var EmployeeMobile: String?{
        get{return self.employeeMobile}
        set{self.employeeMobile = newValue}
    }
    var EmployeeAddress: String?{
        get{return self.employeeAddress}
        set{self.employeeAddress = newValue}
    }
    
    var EmployeeDesignation: String?{
        get{return self.employeeDesignation}
        set{self.employeeDesignation = newValue}
    }
    var EmployeeSinNumber: String?{
        get{return self.employeeSinNumber}
        set{self.employeeSinNumber = newValue}
    }
    
    init(){
    self.employeeID = 0
    self.employeeName = ""
    self.employeeEmail = ""
    self.employeeMobile = ""
    self.employeeAddress = ""
    self.employeeDesignation = ""
    self.EmployeeSinNumber = ""
    
    }
    init(employeeID: Int, employeeName: String, employeeEmail: String, employeeMobile: String, employeeAddress: String, employeeDesignation: String, employeeSinNumber: String) {
        
        self.employeeID = employeeID
        self.employeeName = employeeName
        self.employeeEmail = employeeEmail
        self.employeeMobile = employeeMobile
        self.employeeAddress = employeeAddress
        self.employeeDesignation = employeeDesignation
        self.employeeSinNumber = employeeSinNumber
        
}
    func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Employee ID: \(self.employeeID)"
        returnData += "\n Employee Name: \(self.employeeName ?? "")"
        returnData += "\n Employee Email: \(self.employeeEmail ?? "")"
        returnData += "\n Employee Mobile: \(self.employeeMobile ?? "")"
        returnData += "\n Employee Address : \(self.employeeAddress ?? "")"
        returnData += "\n Employee Designation: \(self.employeeDesignation ?? "")"
        returnData += "\n Employee SIN Number: \(self.EmployeeSinNumber ?? "")"
    
    
        return returnData
    }
    
    func newEmployee(){
        print("Enter Employee ID : ")
        self.employeeID = (Int)(readLine()!)!
        print("Enter Employee Name : ")
        self.employeeName = readLine()
        print("Enter Employee Email : ")
        self.employeeEmail = readLine()
        print("Enter Employee Mobile : ")
        self.employeeMobile = readLine()
        print("Enter Employee Address : ")
        self.employeeAddress = readLine()
        print("Enter Employee Designation : ")
        self.employeeDesignation = readLine()
        print("Enter Employee SIN Number : ")
        self.EmployeeSinNumber = readLine()
    }
        
    
}

