//
//  Protocols.swift
//  AirlineReservationSystem
//
//  Created by Jiya Patreja on 2018-07-21.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import Foundation

protocol IDisplay{
    func displayData() -> String
    
}



public protocol CaseIterable {
    associatedtype AllCases: Collection where AllCases.Element == Self
    static var allCases: AllCases { get }
}
