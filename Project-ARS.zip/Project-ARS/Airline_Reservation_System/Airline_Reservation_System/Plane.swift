//
//  Plane.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Plane{
    var planeID: String?
    var totalSeat: String?
    var seatMap: String?
    
    
    init(planeID: String, totalSeat: String, seatMap: String) {
        
        self.planeID = planeID
        self.totalSeat = totalSeat
        self.seatMap = seatMap
        
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.planeID != nil{
            returnData += "\n Plane ID : " + self.planeID!
        }
        
        if self.totalSeat != nil{
           returnData += "\n Total Seats : " + self.totalSeat!
        }
        if self.seatMap != nil{
            returnData += "\n Seat Map : " + self.seatMap!
        }
        return returnData

    }
   
}
