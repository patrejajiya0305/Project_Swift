//
//  Employee.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class Employee{
    var employeeID: String?
    var employeeName: String?
    var email: String?
    var mobile: String?
    var address: String?
    var designation: String?
    var sinNumber: String?
    
    
    init(employeeID: String, employeeName: String, email: String, mobile: String, address: String, designation: String, sinNumber: String){
        
        self.employeeID = employeeID
        self.employeeName = employeeName
        self.email = email
        self.mobile = mobile
        self.address = address
        self.designation = designation
        self.sinNumber = sinNumber
        
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.employeeID != nil{
            returnData += "\n Employee ID : " + self.employeeID!
        }
        if self.employeeName != nil{
            returnData += "\n employee Name : " + self.employeeName!
        }
        if self.email != nil{
            returnData += "\n Employee Email : " + self.email!
        }
        if self.mobile != nil{
            returnData += "\n Employee Contact : " + self.mobile!
        }
            
        if self.address != nil{
            returnData += "\n Employee Address : " + self.address!
        }
        if self.designation != nil{
            returnData += "\n Designation : " + self.designation!
        }
        if self.sinNumber != nil{
            returnData += "\n SIN Number : " + self.sinNumber!
        }
        
        return returnData
    }
}
