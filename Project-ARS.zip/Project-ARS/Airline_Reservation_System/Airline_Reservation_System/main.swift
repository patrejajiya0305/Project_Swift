//
//  main.swift
//  Airline_Reservation_System
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation



var Boeing = Plane(planeID: "P1223",totalSeat:"1000",seatMap: "A1,A2,A3")

print(Boeing.displayData())


var jiya = Employee(employeeID: "P101",employeeName: "Paramjeet",email: "param@mad.com",mobile: "889 966 5577", address: "Brampton", designation: "pilot", sinNumber: "987-156-365")

print(jiya.displayData())
