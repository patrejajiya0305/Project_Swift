//
//  Student.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation // with open kw can be accessed in another module

// final class Student
//open
//fileprivate


class Student {     //with final keyword we cannot inherit the class in another class
    var name: String?
    static var accNo: Int?
    static var countSt =  0

    
    init(){
       // fileprivate with this means cant be accsed outside the class
        self.name = "Unknown"
        Student.accNo = 000
        Student.countSt += 1 //static var can't be acceseed by instance--- use class name
    }
    func display() {
        print("StudentName : \(self.name ?? "Unknown")")
        print("fees account no  : \(Student.accNo ?? 000)")
    }
    static func getStudentCount() -> Int {
        return countSt
    }
}

class PartTime : Student{
    var hours : Int?
    
   override init() {
    super.init()
        self.hours = 10
        
        
    }
    override func display() {
        print("Hours : \(self.hours ?? 40)")
        
        
    }

}
//var if final -- static
//func if final -- cant be overridden
//class if final --- not inherited
