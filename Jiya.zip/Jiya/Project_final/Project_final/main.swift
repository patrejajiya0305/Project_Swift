//
//  main.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation




/*var Boeing = Plane(planeID: "P101", totalSeat: 1000, seatMap: "A1,A2,A3" , seatType: SeatCategory.BusinessClass , planeType : PlaneCategory.Airbus)

print(Boeing.displayData())

var Jiya = Employee()
Jiya.addEmployee()
print(Jiya.displayData())


//var epson = Product(productID: 101, productName: "Projector", manufacturer: "Epson", unitPrice: 1000.23, category: ProductCategory.Appliances)

//print(epson.displayData())

var Ishav = Passenger()
Ishav.addPassenger()
print(Ishav.displayData())

var AirCanada = Airlines(airlinesID: 102, airlinesDescription : "Full service International and domestic flights", airlinesType : "BritishAirways")

print(AirCanada.displayData())

var Jet = Flight()
Jet.addFlight()
print(Jet.displayData())

var Occupy = Reservation()
Occupy.addReservation()
print(Occupy.displayData())*/

var club = AirlinesEnquiry(airlinesID : 309, enquiryID: 102, enquiryType : "Regarding Departure", enquiryTitle : "Airlines", enquiryDescription : "Regarding Arrival", enquiryDate : "12-09-2018"  )

print(club.displayData())







