//
//  main.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var flight1 = Flight(flightID: 1, flightFrom: "Vancouver", flightTo: "Toronto", flightScheduleDate: "15-Aug-2018", flightType: FlightCategory.Domestic)

var flight2 = Flight(flightID: 2, flightFrom: "India", flightTo: "Toronto", flightScheduleDate: "20-Sept-2018", flightType: FlightCategory.International)

var flight3 = Flight(flightID: 3, flightFrom: "Calgary", flightTo: "Vancouver", flightScheduleDate: "12-Aug-2018", flightType: FlightCategory.Domestic)

var flight4 = Flight(flightID: 4, flightFrom: "Vancouver", flightTo: "Mumbai", flightScheduleDate: "14-Oct-2018", flightType: FlightCategory.International)

/* switch {

default :
}*/



/*var res = Reservation()
res.addReservation()
(res.displayData())*/








