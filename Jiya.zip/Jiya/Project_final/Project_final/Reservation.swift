//
//  Reservation.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class Reservation : Passenger {
    
    var reservationID: Int?
    var reservationDescription: String?
    var reservationPassengerID: String?
    var reservationFlightID : String?
    var reservationDate: String? //date
    var reservationSeatNumber: String?
    var reservationStatus: String?
    var reservationMealType: String?
    
    
    var ReservationID: Int?{
        get{return self.reservationID!}
        set{self.reservationID = newValue}
    }
    
    var ReservationDescription : String?{
        get{return self.reservationDescription}
        set{self.reservationDescription = newValue}
    }
    var ReservationPassengerID: String?{
     get{return self.reservationPassengerID}
     set{self.reservationPassengerID = newValue}
     }
     var ReservationFlightID: String?{
     get{return self.reservationFlightID}
     set{self.reservationFlightID = newValue}
     }
    var ReservationDate: String?{
        get{return self.reservationDate}
        set{self.reservationDate = newValue}
    }
    var ReservationSeatNumber: String?{
        get{return self.reservationSeatNumber}
        set{self.reservationSeatNumber = newValue}
    }
    var ReservationStatus: String?{
        get{return self.reservationStatus}
        set{self.reservationStatus = newValue}
    }
    var ReservationMealType: String?{
        get{return self.reservationMealType}
        set{self.reservationMealType = newValue}
    }
    
    
    override init(){
        self.reservationID = 0
        self.reservationDescription = ""
        self.reservationPassengerID = ""
        self.reservationFlightID = ""
        self.reservationDate = ""
        self.reservationSeatNumber = ""
        self.reservationStatus = ""
        self.reservationMealType = ""
        super.init()
        
        
    }
     init(flightID : Int ,passengerID : Int, reservationID: Int, reservationDescription: String ,reservationPassengerID: String, reservationFlightID : String, reservationFlight reservationDate: String,  reservationSeatNumber: String, reservationStatus: String, reservationMealType: String) {
        
        super.init(flightID : flightID, passengerID : passengerID)
        self.reservationID = reservationID
        self.reservationDescription = reservationDescription
        self.reservationPassengerID = reservationPassengerID
        self.reservationFlightID = reservationFlightID
        self.reservationDate = reservationDate
        self.reservationSeatNumber = reservationSeatNumber
        self.reservationStatus = reservationStatus
        self.reservationMealType = reservationMealType
        
        
    }
    
    override init(flightID: Int, passengerID: Int, passengerPassportNumber: String, passengerName: String, passengerMobile: String, passengerEmail: String, passengerAddress: String, passengerBirthDate: String) {
       super.init(flightID: Int, passengerID: <#T##Int#>, passengerPassportNumber: <#T##String#>, passengerName: <#T##String#>, passengerMobile: <#T##String#>, passengerEmail: <#T##String#>, passengerAddress: <#T##String#>, passengerBirthDate: <#T##String#>)
    }
    
    
    
    
    
    
    override func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Flight ID: \(self.flightID)"
        returnData += "\n Passenger ID: \(self.passengerID)"
        returnData += "\n Reservation ID: \(self.reservationID)"
        returnData += "\n Reservation Description: \(self.reservationDescription ?? "")"
        /* returnData += "\n Passenger Name: \(self.passengerName ?? "")"
         returnData += "\n Passenger Mobile: \(self.passengerMobile ?? "")" */
        returnData += "\n Reservation Date: \(self.reservationDate ?? "")"
        returnData += "\n Reservation Seat Number : \(self.reservationSeatNumber ?? "")"
        returnData += "\n Reservation Status: \(self.reservationStatus ?? "")"
        returnData += "\n Rreservation Meal Type: \(self.reservationMealType ?? "")"
        
        
        return returnData
    }
    
    func addReservation(){
        print("Enter Reservation ID : ")
        self.reservationID = (Int)(readLine()!)!
        print("Enter Reservation Description : ")
        self.reservationDescription = readLine()
        /*print("Enter Passenger Name : ")
         self.passengerName = readLine()
         print("Enter Passenger Mobile : ")
         self.passengerMobile = readLine()*/
        print("Enter Reservation Date : ")
        self.reservationDate = readLine()
        print("Enter Reservation Seat Number : ")
        self.reservationSeatNumber = readLine()
        print("Enter Reservation Status : ")
        self.reservationStatus = readLine()
        print("Enter Reservation Meal Type : ")
        self.reservationMealType = readLine()
        
    }
    
    
}



