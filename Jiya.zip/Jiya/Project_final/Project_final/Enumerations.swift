//
//  Enumerations.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

enum SeatCategory : Int, CaseIterable {
    
    case EconomyClass = 1
    case FirstClass = 2
    case BusinessClass = 3
    case None = 4
    
}

enum PlaneCategory : Int, CaseIterable {
    
    
    case Boeing = 1
    case Airbus = 2
    case Lockheed = 3
    case Gulfstream = 4
    case None = 5
}

enum FlightCategory : Int, CaseIterable {
    
    
    case Domestic = 1
    case International = 2
    case None = 3
    
}


extension CaseIterable where Self: Hashable {
    static var allCases: [Self] {
        return [Self](AnySequence { () -> AnyIterator<Self> in
            var raw = 0
            var first: Self?
            return AnyIterator {
                let current = withUnsafeBytes(of: &raw) { $0.load(as: Self.self) }
                if raw == 0 {
                    first = current
                } else if current == first {
                    return nil
                }
                raw += 1
                return current
            }
        })
    }
}

