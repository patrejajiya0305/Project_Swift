//
//  Datahelper.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class DataHelper{
    var flightList = [Int : Flight]()
    var airlinesList = [Int : Airlines]()
    
    init(){
        self.loadFlightData()
        self.loadAirData()
    
    
}
    func loadFlightData(){
        flightList = [:]
        
        do{
            
     

let flight1 = try Flight(flightID: 1, flightFrom: "Vancouver", flightTo: "Toronto", flightScheduleDate: "15-Aug-2018", flightType: FlightCategory.Domestic)
            flightList[(flight1.flightID!)] = flight1
 
let flight2 = try Flight(flightID: 2, flightFrom: "India", flightTo: "Toronto", flightScheduleDate: "20-Sept-2018", flightType: FlightCategory.International)
            flightList[(flight2.flightID!)] = flight2
 
let flight3 = try Flight(flightID: 3, flightFrom: "Calgary", flightTo: "Vancouver", flightScheduleDate: "12-Aug-2018", flightType: FlightCategory.Domestic)
            flightList[(flight3.flightID!)] = flight3
 
let flight4 = try Flight(flightID: 4, flightFrom: "Vancouver", flightTo: "Mumbai", flightScheduleDate: "14-Oct-2018", flightType: FlightCategory.International)
            flightList[(flight4.flightID!)] = flight4

        }catch{
            print("Error: \(error)")
       
            
       
}
}
    func displayFlight(){
    print("Flight Details")
        Util.drawLine()
    print("\t FlightID \t\t Flight from \t\t\t\t Flight to \t\t Flight Schedule Date \t\t Flight Type")
    for (_, value) in self.flightList.sorted(by: { $0.key < $1.key }){
      Util.drawLine()
    print("\t \(value.flightID!) ------ \(value.flightFrom!) ------ \(value.flightTo!) ------ \(value.flightScheduleDate!) ------ \(value.flightType!)")
    }
        Util.drawLine()
        
    }


    func loadAirData(){
        airlinesList = [:]
        
        do{
            
            
            
            let air1 = try Airlines(airlinesID: 123, airlinesDescription: "Fly with Us", airlinesType: "Jahaj")
            airlinesList[(air1.airlinesID!)] =  air1
            
            let air2 = try Airlines(airlinesID: 584, airlinesDescription: "good airlines",  airlinesType:"Dusra Jahaj" )
            airlinesList[(air2.airlinesID!)] =  air2
            
            let air3 = try Airlines(airlinesID: 628, airlinesDescription: "fast lane",  airlinesType:"3rd jahaj" )
            airlinesList[(air3.airlinesID!)] =  air3
            
            let air4 = try Airlines(airlinesID: 765, airlinesDescription: "big plane",  airlinesType:"4th jahaj" )
            airlinesList[(air4.airlinesID!)] =  air4
            
        }catch{
            print("Error: \(error)")
            
        }
    }
    func displayAirlines(){
        print("Airlines Details")
        Util.drawLine()
        print("\t AirlinesID \t\t Airlines Description  \t\t Airlines Type ")
        for (_, value) in self.airlinesList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print("\t \(value.airlinesID!) ------ \(value.airlinesDescription!) ------ \(value.AirlinesType!)")
        }
        Util.drawLine()
    }}













