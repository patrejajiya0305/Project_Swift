//
//  Reservation.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class Reservation : Passenger {
    
    var reservationID: Int?
    var reservationDescription: String?
    var reservationPassengerID: String?
    var reservationFlightID : String?
    var reservationDate: String? //date
    var reservationSeatNumber: String?
    var reservationStatus: String?
    var reservationMealType: String?
    var totalSeats = 100
    var availableSeats = 50
    
    
    var ReservationID: Int?{
        get{return self.reservationID!}
        set{self.reservationID = newValue}
    }
    
    var ReservationDescription : String?{
        get{return self.reservationDescription}
        set{self.reservationDescription = newValue}
    }
    var ReservationPassengerID: String?{
     get{return self.reservationPassengerID}
     set{self.reservationPassengerID = newValue}
     }
     var ReservationFlightID: String?{
     get{return self.reservationFlightID}
     set{self.reservationFlightID = newValue}
     }
    var ReservationDate: String?{
        get{return self.reservationDate}
        set{self.reservationDate = newValue}
    }
    var ReservationSeatNumber: String?{
        get{return self.reservationSeatNumber}
        set{self.reservationSeatNumber = newValue}
    }
    var ReservationStatus: String?{
        get{return self.reservationStatus}
        set{self.reservationStatus = newValue}
    }
    var ReservationMealType: String?{
        get{return self.reservationMealType}
        set{self.reservationMealType = newValue}
    }
    
    func getAvailSeats()-> Int
    {
        return availableSeats
    }
    
    override init(){
        self.reservationID = 0
        self.reservationDescription = ""
        self.reservationPassengerID = ""
        self.reservationFlightID = ""
        self.reservationDate = ""
        self.reservationSeatNumber = ""
        self.reservationStatus = ""
        self.reservationMealType = ""
        super.init()
        
        
    }
     init(flightID : Int ,passengerID : Int, reservationID: Int, reservationDescription: String ,reservationPassengerID: String, reservationFlightID : String, reservationDate: String,  reservationSeatNumber: String, reservationStatus: String, reservationMealType: String) {
        
        super.init()
        var p = Passenger( passengerID: passengerID, passengerPassportNumber:
            passengerPassportNumber!,  passengerName: passengerName!,   passengerMobile: passengerMobile!,   passengerEmail: passengerEmail! ,  passengerAddress: passengerAddress! ,passengerBirthDate : passengerBirthDate!)
        
        
       
        self.reservationID = reservationID
        self.reservationDescription = reservationDescription
        self.reservationPassengerID = reservationPassengerID
        self.reservationFlightID = reservationFlightID
        self.reservationDate = reservationDate
        self.reservationSeatNumber = reservationSeatNumber
        self.reservationStatus = reservationStatus
        self.reservationMealType = reservationMealType
      
    }
    
    
    
    
    override func displayData() -> String {
        var returnData = ""
        
      
        returnData += "\n Passenger ID: \(self.reservationPassengerID!))"
        returnData += "\n Reservation ID: \(self.reservationID!)"
        returnData += "\n Reservation Description: \(self.reservationDescription ?? "")"
        
        returnData += "\n Reservation Date: \(self.reservationDate ?? "")"
        returnData += "\n Reservation Seat Number : \(self.reservationSeatNumber ?? "")"
        returnData += "\n Reservation Status: \(self.reservationStatus ?? "")"
        returnData += "\n Reservation Meal Type: \(self.reservationMealType ?? "")"
        
        
        return returnData
    }
    
    func addReservation(){
        
      
        print("Enter Reservation ID : ")
        self.reservationID = (Int)(readLine()!)!
        print("Enter Reservation Description : ")
        self.reservationDescription = readLine()
        print("Enter Reservation Date : ")
        self.reservationDate = readLine()
        print("Enter Reservation Seat Number : ")
        self.reservationSeatNumber = readLine()
        
        print("Enter Reservation Meal Type : ")
        self.reservationMealType = readLine()
        
    }
    
    
}



