//
//  main.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var choice = 1
let dataHelper = DataHelper()
var flight = Flight()
var reservation = Reservation()
var choice2 : String
var seats : Int
var res =  Reservation()
var avSeats : Int
var pass = Passenger()
var passData : String
var pid : Int
avSeats = 0
passData = ""
seats = 0

func  fl()
{
    print("How many seats you want to reserve")
    seats = Int(readLine()!)!
    avSeats = res.getAvailSeats()
    if(seats > avSeats)
    {
        print("sorry ! only \(avSeats) available")
    }
    else
    {
        pass.addPassenger()
        passData = pass.displayData()
        print(passData)
        
        print("\nselect meal type")
        var meal = readLine()
        
        res =  Reservation(flightID : 1 ,passengerID : pass.passengerID!, reservationID : 4545 , reservationDescription: "Description" ,reservationPassengerID: "4545", reservationFlightID : "1", reservationDate: "2018/09/10",  reservationSeatNumber: "not allocated", reservationStatus: "confirmed", reservationMealType: meal! )
        print("\nYour reservation details")
        
        print(res.displayData())
        
        print("\nThank you \(pass.passengerName!) reservation" )
        print("You will get email from us about your reservation")
        
    }
}

while choice != 3{
    
    print("\t 1 : Flight Details ")
    print("\t 2 : Airlines Details ")
    print("\t 3 : Exit")
    
    
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
    case 1:
        dataHelper.displayFlight()
         print("Select your flight")
        choice2 = readLine()!
        switch(choice2)
        {
        case "1" :
            flight = Flight(flightID: 1, flightFrom: "Vancouver", flightTo: "Toronto", flightScheduleDate: "15-Aug-2018", flightType: FlightCategory.Domestic)
           print("flight 1 selected")
      fl()
            
        case "2" :
          flight = Flight(flightID: 2, flightFrom: "India", flightTo: "Toronto", flightScheduleDate: "20-Sept-2018", flightType: FlightCategory.International)
             print("flight 2 selected")
            
        
     fl()
        
            
        default:
          print("ishav airline")
        }
        
        case 2:
            dataHelper.displayAirlines()

        
  
   
    case 3:
        exit(0)
    
    default:
        print("Please enter valid menu option.")
    }
}

/* switch {

default :
}*/



/*var res = Reservation()
res.addReservation()
(res.displayData())*/








